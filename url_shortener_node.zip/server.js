
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const shortid = require('shortid');
const path = require('path');

dotenv.config();

const app = express();
const Url = require('./models/Url');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: false }));

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB error:', err));

app.get('/', (req, res) => {
  res.render('index', { shortUrl: null });
});

app.post('/shorten', async (req, res) => {
  const { originalUrl } = req.body;

  if (!originalUrl) return res.redirect('/');

  let existing = await Url.findOne({ originalUrl });
  if (existing) {
    return res.render('index', { shortUrl: `${req.headers.host}/${existing.shortCode}` });
  }

  const shortCode = shortid.generate();
  const url = new Url({ originalUrl, shortCode });
  await url.save();

  res.render('index', { shortUrl: `${req.headers.host}/${shortCode}` });
});

app.get('/:shortCode', async (req, res) => {
  const short = await Url.findOne({ shortCode: req.params.shortCode });
  if (short) {
    return res.redirect(short.originalUrl);
  }
  res.status(404).send('URL not found');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
